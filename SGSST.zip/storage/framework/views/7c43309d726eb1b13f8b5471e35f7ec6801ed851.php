
<?php $__env->startSection('title', 'Cápsula'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.argon_nav_user_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mb-4 mt-5">
        <div class="card shadow">
            <div class="card-header bg-translucent-white"></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="<?php echo e($capsule->video); ?>" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12 <?php echo e(checkColCapsule(session('role'))); ?> mt-4">
                    <div class="card shadow">
                        <div class="card-header bg-translucent-white">
                            <h2 class="mt-3 font-weight-bold">Información Cápsula</h2>
                        </div>
                        <div class="card-body">
                            <?php if(session('role') != 'capacitante'): ?>
                                <p class="card-text">Para actualizar la cápsula, llena las credenciales</p>
                            <?php endif; ?>
                            <form action="<?php echo e(route('capsule.update')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <input type="hidden" name="capsule" value="<?php echo e($capsule->id); ?>">
                                <div class="form-group">
                                    <label for="title" class="font-weight-bold">Tiutlo</label>
                                    <input type="text" name="title" id="title"
                                        class="form-control text-capitalize <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e($capsule->title); ?>" aria-describedby="helpId"
                                        <?php echo e(checkInput(session('role'))); ?>>
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small id="helpId"
                                            class="font-weight-bold bg-danger py-y text-white"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php if(session('role') != 'capacitante'): ?>
                                    <div class="form-group">
                                        <label for="video" class="font-weight-bold">Video</label>
                                        <input type="text" name="video" id="video"
                                            class="form-control <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e($capsule->video); ?>" aria-describedby="helpId"
                                            <?php echo e(checkInput(session('role'))); ?>>
                                        <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId"
                                                class="font-weight-bold bg-danger py-y text-white"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="form-group">
                                    <label for="info" class="font-weight-bold">Descripción</label>
                                    <textarea class="form-control <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="info" id="info"
                                        rows="3" <?php echo e(checkInput(session('role'))); ?>><?php echo e($capsule->info); ?></textarea>
                                    <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small id="helpId"
                                            class="font-weight-bold bg-danger py-y text-white"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php if(session('role') != 'capacitante'): ?>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-block btn-default">Actualizar</button>
                                    </div>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
                <?php if(session('role') != 'capacitante'): ?>
                    <div class="col-12 col-md-12 col-lg-12 col-xl-4 mt-4">
                        <div class="card shadow">
                            <div class="card-header bg-translucent-white">
                                <h2 class="font-weight-bold mt-3">Cambiar temática</h2>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('capsule.changeTopic')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('patch'); ?>
                                    <input type="hidden" name="capsule" value="<?php echo e($capsule->id); ?>">
                                    <div class="form-group">
                                        <label for="topic" class="font-weight-bold">Temática</label>
                                        <select class="form-control" name="topic" id="topic">
                                            <option value="-1">Seleccione una temática</option>
                                            <?php $__currentLoopData = $tematicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($topic->id == $capsule->topic->id): ?>
                                                    <option value="<?php echo e($topic->id); ?>" selected><?php echo e($topic->title); ?>

                                                    </option>
                                                <?php endif; ?>
                                                <option value="<?php echo e($topic->id); ?>"><?php echo e($topic->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-block btn-default">Cambiar
                                            temática</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php if(session()->has('update_complete')): ?>
        <script>
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: '¡Éxito!',
                text: "<?php echo e(session('update_complete')); ?>",
                showConfirmButton: false,
                timer: 1500
            })

        </script>
    <?php endif; ?>
    <?php if(session()->has('update_failed')): ?>
        <script>
            Swal.fire({
                position: 'top-end',
                icon: 'error',
                title: "¡Error!",
                text: "<?php echo e(session('update_failed')); ?>",
                showConfirmButton: false,
                timer: 1500
            })

        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.argon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/auth/profiles/capsule.blade.php ENDPATH**/ ?>