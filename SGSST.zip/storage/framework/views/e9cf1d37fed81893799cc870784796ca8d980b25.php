<!--
=========================================================
* Argon Dashboard - v1.2.0
=========================================================
* Product Page: https://www.creative-tim.com/product/argon-dashboard


* Copyright  Creative Tim (http://www.creative-tim.com)
* Coded by www.creative-tim.com



=========================================================
* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- CSS -->

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('dashboard/img/brand/favicon.png')); ?>" type="image/png">
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/nucleo/css/nucleo.css')); ?>" type="text/css">
    
    <!-- Page plugins -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <!-- Argon CSS -->
    


</head>

<body>
    <!-- Sidenav -->
    
    <!-- Main content -->
    <div class="main-content" id="panel">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- Argon Scripts -->
    <!-- Core -->
    <script src="<?php echo e(asset('dashboard/vendor/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/js-cookie/js.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>
    <!-- Optional JS -->
    <script src="<?php echo e(asset('dashboard/vendor/chart.js/dist/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/chart.js/dist/Chart.extension.js')); ?>"></script>
    <!-- Argon JS -->
    <script src="<?php echo e(asset('dashboard/js/argon.js?v=1.2.0')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>


    <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/layouts/argon_blade_2.blade.php ENDPATH**/ ?>