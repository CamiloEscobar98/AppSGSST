
<?php $__env->startSection('title', 'Perfil/Usuario'); ?>
<?php $__env->startSection('content'); ?>
    <section class="container-fluid mb-4">
        <div class="row justify-content-center">
            <div class="col-md-3 mt-5">
                <div class="row">
                    <div class="col-12">
                        <div class="card shadow">
                            <div class="card-header bg-sgsst2 py-5"></div>
                            <div class="card-body">
                                <img src="<?php echo e(asset($usuario->image->url . '/' . $usuario->image->image)); ?>"
                                    class="img-fluid ${3|rounded-top,rounded-right,rounded-bottom,rounded-left,rounded-circle,|} mx-auto d-block"
                                    alt="Foto de perfil" width="200vh">
                                <form action="<?php echo e(route('user.update-photo')); ?>" method="POST" class="mt-4"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="email" value="<?php echo e($usuario->email); ?>">
                                    <?php echo method_field('patch'); ?>
                                    <div class="form-group">
                                        <div class="custom-file">
                                            <input type="file"
                                                class="custom-file-input <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="customFile" name="image">
                                            <label class="custom-file-label" for="customFile">Seleccionar foto de
                                                perfil</label>
                                        </div>
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId"
                                                class="form-text bg-danger font-weight-bold py-2 text-white px-2"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-login btn-block">Actualizar foto</button>
                                    </div>
                                </form>
                            </div>
                            <div class="card-footer bg-sgsst2 py-4"></div>
                        </div>
                    </div>
                    <div class="col-12 mt-4">
                        <div class="card">
                            <div class="card-header bg-sgsst2 py-4 text-center">
                                <h4 class="font-weight-bold my-0 text-white">Asignar rol de Usuario</h4>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('user.addRole')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="email" value="<?php echo e($usuario->email); ?>">
                                    <div class="form-group">
                                        <label for="role" class="font-weight-bold">Rol de Usuario</label>
                                        <select name="role" id="role"
                                            class="custom-select <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="-1">Seleccione una opción</option>
                                            <?php $__currentLoopData = $roles->except(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId"
                                                class="form-text text-white bg-danger py-2 px-2 font-weight-bold"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-block btn-login">Agregar</button>
                                    </div>
                                </form>
                            </div>
                            <div class="card-footer bg-sgsst2 py-4"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mt-5">
                <div class="card shadow">
                    <div class="card-header bg-sgsst2 py-5"></div>
                    <div class="card-body">
                        <h4 class="card-title float-right">Perfil de usuario</h4>
                        <p class="card-text">Actualiza tu información</p>
                        <?php echo $__env->make('layouts.user.update-form-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <hr class="bg-sgsst my-4">
                        <h4 class="font-weight-bold">Roles Asignados</h4>
                        <ul class="list-group">
                            <?php $__empty_1 = true; $__currentLoopData = $usuario->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center shadow-sm"
                                    id="fila<?php echo e($loop->iteration); ?>">
                                    <p class="my-0 text-capitalize"> <?php echo e($role->name); ?></p>
                                    <button type="button" class="btn btn-danger delete-role" data-tr="<?php echo e($loop->iteration); ?>"
                                        data-role="<?php echo e($role->name); ?>">
                                        <i class="fa fa-trash" aria-hidden="true"></i>
                                    </button>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center shadow-sm">
                                    Ningún rol asignado
                                </li>
                            <?php endif; ?>

                        </ul>
                    </div>
                    <div class="card-footer bg-sgsst2 py-4"></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="row">
                    <div class="col-12 mt-5">
                        <div class="card shadow">
                            <div class="card-header bg-sgsst2 py-4">
                                <h4 class="my-0 font-weight-bold text-center">Cambiar contraseña</h4>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('user.update-password')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('patch'); ?>
                                    <input type="hidden" name="email" value="<?php echo e($usuario->email); ?>">
                                    <div class="form-group">
                                        <label for="password" class="font-weight-bold text-capitalize">Nueva
                                            contraseña:</label>
                                        <input type="password" class="form-control" name="password" id="password"
                                            aria-describedby="helpId" placeholder="Escribe tu nombre.."
                                            value="<?php echo e(old('password')); ?>">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId"
                                                class="form-text text-white bg-danger py-2 px-2 font-weight-bold"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-login btn-block">Actualizar contraseña</button>
                                    </div>
                                </form>
                            </div>
                            <div class="card-footer bg-sgsst2 py-4"></div>
                        </div>
                    </div>
                    <?php if(session('role') == 'administrador'): ?>
                        <div class="col-12 mt-4">
                            <div class="card shadow">
                                <div class="card-header bg-sgsst2 py-4">
                                    <h4 class="my-0 font-weight-bold text-center">Cambiar tipo de documento</h4>
                                </div>
                                <div class="card-body">
                                    <form action="<?php echo e(route('user.update-document')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('patch'); ?>
                                        <input type="hidden" name="email" value="<?php echo e($usuario->email); ?>">
                                        <div class="form-group">
                                            <label for="document_type_id" class="font-weight-bold text-capitalize">Tipo de
                                                documento:</label>
                                            <select name="document_type_id" id="document_type_id"
                                                class="custom-select text-capitalize" aria-describedby="helpId">
                                                <option value="-1" class="text-capitalize">Seleccione una opción</option>
                                                <?php $__currentLoopData = $document_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($usuario->document->document_type_id == $document_type->id): ?>
                                                        <option class="text-capitalize" value="<?php echo e($document_type->id); ?>"
                                                            selected>
                                                            <?php echo e($document_type->info); ?>

                                                        </option>
                                                    <?php else: ?>
                                                        <option class="text-capitalize" value="<?php echo e($document_type->id); ?>">
                                                            <?php echo e($document_type->info); ?>

                                                        </option>
                                                    <?php endif; ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['document_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="helpId"
                                                    class="form-text text-white bg-danger font-weight-bold py-2 px-2"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-login btn-block">Actualizar</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="card-footer bg-sgsst2 py-4"></div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    // Add the following code if you want the name of the file appear on select
    $(".custom-file-input").on("change", function() {
        var fileName = $(this).val().split("\\").pop();
        $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
    });

</script>
<?php if(session()->has('update_complete')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '¡Éxito!',
            text: "<?php echo e(session('update_complete')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('update_failed')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "¡Error!",
            text: "<?php echo e(session('update_failed')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<script>
    $('.delete-role').on('click', function() {
        var role = $(this).attr('data-role');
        var usuario = "<?php echo e($usuario->email); ?>";
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡El rol " + role.toUpperCase() + " Será eliminado!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '¡Si, eliminalo!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                axios.post("<?php echo e(route('user.deleteRole')); ?>", {
                    _method: 'delete',
                    usuario: usuario,
                    role: role
                }).then(response => {
                    console.log(response.data);
                    Swal.fire(
                        'Eliminado!',
                        response.data,
                        'success'
                    )

                });
                var fila = $(this).attr('data-tr');
                $("#fila" + fila).remove();
            }
        })
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/auth/profiles/usuario.blade.php ENDPATH**/ ?>