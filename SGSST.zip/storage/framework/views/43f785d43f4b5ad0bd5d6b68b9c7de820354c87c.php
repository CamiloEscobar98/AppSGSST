
<?php $__env->startSection('title', 'Temáticas'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.argon_nav_user_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-12 col-md-3 my-4">
                    <div class="card h-100 rounded">
                        <div class="card-header bg-default"></div>
                        <div class="card-body">
                            <img src="<?php echo e(asset($topic->image->fullimage())); ?>"
                                class="img-fluid ${3|rounded-top,rounded-right,rounded-bottom,rounded-left,rounded-circle,|} mx-auto d-block"
                                alt="" width="100vh">
                            <h4 class="card-title font-weight-bold">Tema </h4>
                            <div class="card-text">
                                <p> <?php echo e($topic->title); ?></p>
                            </div>
                            <div class="card-title">
                                Descripción
                            </div>
                            <p><?php echo e($topic->info); ?></p>
                        </div>
                        <div class="card-footer bg-sgsst2 py-4">
                            <a href="<?php echo e(route('topic.show', $topic)); ?>" class="btn btn-outline-default"><i class="fa fa-eye mr-2"
                                    aria-hidden="true"></i>Ver</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-8 mx-auto text-center my-4">
                    <div class="alert alert-danger">
                        <strong>No tienes temáticas asignadas. Por favor, solicita que el administrador te asigne alguna
                            temática.</strong>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.argon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/auth/lists/mis-tematicas.blade.php ENDPATH**/ ?>