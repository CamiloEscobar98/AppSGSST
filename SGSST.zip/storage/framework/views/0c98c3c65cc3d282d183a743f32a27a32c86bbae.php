
<?php $__env->startSection('title', 'Cápsulas'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.argon_nav_user_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mb-4">
        <div class="card shadow mt-5">
            <div class="card-header bg-translucent-white">
                <h2 class="font-weight-bold mt-3">Lista de Cápsulas</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="bg-primary font-weight-bold text-white text-center">
                            <tr>
                                <th class="bg-translucent-default">Temática</th>
                                <th class="bg-translucent-white">Título</th>
                                <th class="bg-translucent-default w-50">Descripción</th>
                                <th class="bg-translucent-white" style="width: 5%">...</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $capsulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capsula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="text-center" id="fila<?php echo e($loop->iteration); ?>">
                                    <td><a href="<?php echo e(route('topic.show', $capsula->topic)); ?>"><?php echo e($capsula->topic->title); ?></a>
                                    </td>
                                    <td><?php echo e($capsula->title); ?></td>
                                    <td><?php echo e($capsula->info); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('capsule.show', $capsula)); ?>" type="button"
                                                class="btn btn-outline-primary mr-2"><i class="fa fa-eye"
                                                    aria-hidden="true"></i></a>
                                            <button type="button" class="btn btn-outline-danger  delete-capsule"
                                                data-tr="<?php echo e($loop->iteration); ?>" data-title="<?php echo e($capsula->title); ?>"
                                                data-capsule="<?php echo e($capsula->id); ?>"><i class="fa fa-trash"
                                                    aria-hidden="true"></i></button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h4 class="text-center my-4">No hay cápsulas registradas.</h4>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="float-left ml-3">
                    <?php echo e($capsulas->links()); ?>

                </div>
            </div>
        </div>
        <div class="card shadow">
            <div class="card-header bg-translucent-white">
                <h2 class="font-weight-bold mt-3">Registrar Cápsula</h2>
            </div>
            <div class="card-body">
                <p class="card-text">Por favor llena toda la información para registrar la cápsula.</p>
                <form action="<?php echo e(route('capsule.create')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="title" class="font-weight-bold">Título:</label>
                                <input type="text" name="title" id="title"
                                    class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder=""
                                    value="<?php echo e(old('title')); ?>" aria-describedby="helpId">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="info" class="font-weight-bold">Descripción:</label>
                                <textarea class="form-control <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="info" id="info"
                                    aria-describedby="helpId" rows="3"><?php echo e(old('info')); ?></textarea>
                                <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="video" class="font-weight-bold">URL del vídeo:</label>
                                <input type="url" name="video" id="video"
                                    class="form-control <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder=""
                                    value="<?php echo e(old('video')); ?>" aria-describedby="helpId">
                                <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="topic" class="font-weight-bold">Temática:</label>
                                <select class="form-control <?php $__errorArgs = ['topic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="topic" id="topic">
                                    <option value="-1">Seleccione una temática</option>
                                    <?php $__currentLoopData = $tematicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tema->id); ?>"><?php echo e($tema->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['topic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white bg-danger py-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group float-right">
                        <button type="submit" class="btn btn-outline-primary">Registrar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('.delete-capsule').on('click', function() {
        var capsule = $(this).attr('data-title');
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡La cápsula " + capsule.toUpperCase() + " Será eliminado!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '¡Si, eliminalo!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                var capsule = $(this).attr('data-capsule');
                axios.post("<?php echo e(route('capsule.delete')); ?>", {
                    _method: 'delete',
                    capsule: capsule,
                }).then(res => {
                    var titulo = (res.data.alert == 'success') ? '¡Eliminado!' : '¡Error';
                    Swal.fire(
                        titulo,
                        res.data.message,
                        res.data.alert
                    )

                });
                var fila = $(this).attr('data-tr');
                $("#fila" + fila).remove();
                setTimeout(() => {
                    location.reload(true)
                }, 2000);
            }
        })
    });

</script>
<?php if(session()->has('create_complete')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '¡Éxito!',
            text: "<?php echo e(session('create_complete')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('create_failed')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "¡Error!",
            text: "<?php echo e(session('create_failed')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.argon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/auth/lists/lista-capsulas.blade.php ENDPATH**/ ?>