
<?php $__env->startSection('title', 'Cápsulas'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid mb-4">
        <div class="row">
            <div class="col-md-4 mt-5">
                <div class="card shadow">
                    <div class="card-header bg-sgsst2 py-4">
                        <h4 class="font-weight-bold my-0">Registrar Cápsula</h4>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Por favor llena toda la información para registrar la cápsula.</p>
                        <form action="<?php echo e(route('capsule.create')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="title" class="font-weight-bold">Título:</label>
                                <input type="text" name="title" id="title"
                                    class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder=""
                                    value="<?php echo e(old('title')); ?>" aria-describedby="helpId">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="info" class="font-weight-bold">Descripción:</label>
                                <textarea class="form-control <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="info" id="info"
                                    aria-describedby="helpId" rows="3"><?php echo e(old('info')); ?></textarea>
                                <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="video" class="font-weight-bold">URL del vídeo:</label>
                                <input type="url" name="video" id="video"
                                    class="form-control <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder=""
                                    value="<?php echo e(old('video')); ?>" aria-describedby="helpId">
                                <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="topic" class="font-weight-bold">Temática:</label>
                                <select class="form-control <?php $__errorArgs = ['topic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="topic" id="topic">
                                    <option value="-1">Seleccione una temática</option>
                                    <?php $__currentLoopData = $tematicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tema->id); ?>"><?php echo e($tema->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['topic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white bg-danger py-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-block btn-login">Registrar</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer bg-sgsst2 py-4"></div>
                </div>
            </div>
            <div class="col-md-8 mt-5">
                <div class="card shadow">
                    <div class="card-header bg-sgsst2 py-4">
                        <h4 class="font-weight-bold text-white my-0">Lista de Cápsulas</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="bg-sgsst2 font-weight-bold text-center">
                                    <tr>
                                        <th class="">Temática</th>
                                        <th class="">Título</th>
                                        <th class="w-50">Descripción</th>
                                        <th>...</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $capsulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capsula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr class="text-center" id="fila<?php echo e($loop->iteration); ?>">
                                            <td><a
                                                    href="<?php echo e(route('topic.show', $capsula->topic)); ?>"><?php echo e($capsula->topic->title); ?></a>
                                            </td>
                                            <td><?php echo e($capsula->title); ?></td>
                                            <td><?php echo e($capsula->info); ?></td>
                                            <td>
                                                <div class="btn-group w-100">
                                                    <a href="<?php echo e(route('capsule.show', $capsula)); ?>" type="button"
                                                        class="btn btn-primary w-50"><i class="fa fa-eye"
                                                            aria-hidden="true"></i></a>
                                                    <button type="button" class="btn btn-danger w-50 delete-capsule"
                                                        data-tr="<?php echo e($loop->iteration); ?>" data-title="<?php echo e($capsula->title); ?>"
                                                        data-capsule="<?php echo e($capsula->id); ?>"><i class="fa fa-trash"
                                                            aria-hidden="true"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>No hay cápsuals registradas</tr>
                                    <?php endif; ?>
                                </tbody>
                                <tfoot class="bg-sgsst2 font-weight-bold text-center">
                                    <th>Encargado</th>
                                    <th>Título</th>
                                    <th>Descripción</th>
                                    <th>...</th>
                                </tfoot>
                            </table>
                        </div>
                        <?php echo e($capsulas->links()); ?>

                    </div>
                    <div class="card-footer bg-sgsst2 py-4"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('.delete-capsule').on('click', function() {
        var capsule = $(this).attr('data-title');
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡La cápsula " + capsule.toUpperCase() + " Será eliminado!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '¡Si, eliminalo!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                var capsule = $(this).attr('data-capsule');
                axios.post("<?php echo e(route('capsule.delete')); ?>", {
                    _method: 'delete',
                    capsule: capsule,
                }).then(res => {
                    var titulo = (res.data.alert == 'success') ? '¡Eliminado!' : '¡Error';
                    Swal.fire(
                        titulo,
                        res.data.message,
                        res.data.alert
                    )

                });
                var fila = $(this).attr('data-tr');
                $("#fila" + fila).remove();
            }
        })
    });

</script>
<?php if(session()->has('create_complete')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '¡Éxito!',
            text: "<?php echo e(session('create_complete')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('create_failed')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "¡Error!",
            text: "<?php echo e(session('create_failed')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/auth/lists/lista-capsulas.blade.php ENDPATH**/ ?>