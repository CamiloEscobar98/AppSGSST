
<?php $__env->startSection('title', 'Capacitantes'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid mb-4 mt-5">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-header bg-sgsst2 py-4">
                        <h4 class="my-0 font-weight-bold">Registrar capacitador</h4>
                    </div>
                    <div class="card-body">
                        <p class="card-title">Por favor llena toda la información para registrar el capacitador.</p>
                        <form action="<?php echo e(route('user.create')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="role" value="capacitador">
                            <div class="form-group">
                                <label for="name" class="font-weight-bold">Nombres:</label>
                                <input type="text" name="name" id="name"
                                    class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>"
                                    aria-describedby="helpId">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId"
                                        class="font-weight-bold text-white bg-danger py-2 px-2"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="lastname" class="font-weight-bold">Apellidos:</label>
                                <input type="text" name="lastname" id="lastname"
                                    class="form-control <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('lastname')); ?>" aria-describedby="helpId">
                                <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId"
                                        class="font-weight-bold text-white bg-danger py-2 px-2"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="email" class="font-weight-bold">Correo electrónico:</label>
                                <input type="email" name="email" id="email"
                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>"
                                    aria-describedby="helpId">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId"
                                        class="font-weight-bold text-white bg-danger py-2 px-2"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="document" class="font-weight-bold">Documento:</label>
                                <input type="text" name="document" id="document"
                                    class="form-control <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('document')); ?>" aria-describedby="helpId" maxlength="15"
                                    onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;">
                                <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId"
                                        class="font-weight-bold text-white bg-danger py-2 px-2"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="document" class="font-weight-bold">Tipo de documento:</label>
                                <select name="document_type_id" id="document_type_id"
                                    class="custom-select text-capitalize <?php $__errorArgs = ['document_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="-1">Seleccione una opción</option>
                                    <?php $__currentLoopData = $document_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($document_type->type); ?>"><?php echo e($document_type->info); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['document_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId"
                                        class="font-weight-bold text-white bg-danger py-2 px-2"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-login btn-block">Registrar</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer bg-sgsst2 py-4"></div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-sgsst2 py-4">
                        <h4 class="my-0 font-weight-bold">Lista de capacitadores</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="bg-sgsst2 font-weight-bold text-center">
                                    <tr>
                                        <th style="width: 5%">No</th>
                                        <th>Capacitador</th>
                                        <th>Correo electrónico</th>
                                        <th>Documento</th>
                                        <th>..</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $capacitadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capacitador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr class="text-center" id="fila<?php echo e($loop->iteration); ?>">
                                            <td> <img src="<?php echo e(asset($capacitador->image->fullimage())); ?>"
                                                    class="img-fluid ${3|rounded-top,rounded-right,rounded-bottom,rounded-left,rounded-circle,|} mx-auto d-block"
                                                    alt="" width="50vh"></td>
                                            <td class="text-capitalize"><?php echo e($capacitador->fullname()); ?></td>
                                            <td><?php echo e($capacitador->email); ?></td>
                                            <td><?php echo e($capacitador->document->document); ?></td>
                                            <td>
                                                <div class="btn-group w-100" role="group" aria-label="opciones">
                                                    <a href="<?php echo e(route('user.show', $capacitador)); ?>" type="button"
                                                        class="btn btn-primary w-50"><i class="fa fa-eye"
                                                            aria-hidden="true"></i></a>
                                                    <button type="button" class="btn btn-danger w-50 delete-user"
                                                        data-user="<?php echo e($capacitador->fullname()); ?>"
                                                        data-tr="<?php echo e($loop->iteration); ?>"
                                                        data-email="<?php echo e($capacitador->email); ?>"><i class="fa fa-trash"
                                                            aria-hidden="true"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            No hay registros
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                                <tfoot class="bg-sgsst2 font-weight-bold text-center">
                                    <th style="width: 5%">No</th>
                                    <th>Capacitador</th>
                                    <th>Correo electrónico</th>
                                    <th>Documento</th>
                                    <th>..</th>
                                </tfoot>
                            </table>
                            <?php echo e($capacitadores->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php if(session()->has('create_complete')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '¡Éxito!',
            text: "<?php echo e(session('create_complete')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('create_failed')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "¡Error!",
            text: "<?php echo e(session('create_failed')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<script>
    $('.delete-user').on('click', function() {
        var usuario = $(this).attr('data-user');
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡El capacitador " + usuario.toUpperCase() + " Será eliminado!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '¡Si, eliminalo!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                var usuario = $(this).attr('data-email');
                axios.post("<?php echo e(route('user.delete')); ?>", {
                    _method: 'delete',
                    usuario: usuario,
                }).then(res => {
                    console.log(res.data);
                    Swal.fire(
                        'Eliminación..',
                        res.data.message,
                        res.data.alert
                    )

                });
                var fila = $(this).attr('data-tr');
                $("#fila" + fila).remove();
                setTimeout(() => {
                        location.reload(true)
                    }, 2000);
            }
        })
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/auth/lists/lista-capacitadores.blade.php ENDPATH**/ ?>