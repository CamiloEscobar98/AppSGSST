
<?php $__env->startSection('title', 'Perfil-Juego'); ?>
<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom">
        <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                <!-- Navbar links -->
                <ul class="navbar-nav align-items-center  ml-md-auto ">
                    <li class="nav-item d-xl-none">
                        <!-- Sidenav toggler -->
                        <div class="pr-3 sidenav-toggler sidenav-toggler-dark" data-action="sidenav-pin"
                            data-target="#sidenav-main">
                            <div class="sidenav-toggler-inner">
                                <i class="sidenav-toggler-line"></i>
                                <i class="sidenav-toggler-line"></i>
                                <i class="sidenav-toggler-line"></i>
                            </div>
                        </div>
                    </li>
                </ul>
                <?php echo $__env->make('layouts.argon_user_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </nav>
    <div class="container-fluid mt-4 mb-4">
        <div class="card">
            <div class="card-header bg-translucent-white">
                <h2 class="font-weight-bold mt-3">Lista de palabras</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover text-center">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th class="bg-translucent-default" style="width: 5%">No.</th>
                                <th class="bg-translucent-white" class="w-50">Palabra</th>
                                <th class="bg-translucent-default" class="w-50">Pista</th>
                                <?php if(session('role') != 'capacitante'): ?>
                                    <th class="bg-translucent-white" style="width: 5%">...</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody class="text-capitalize">
                            <?php $__empty_1 = true; $__currentLoopData = $words; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr id="fila<?php echo e($loop->iteration); ?>">
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($word->word); ?></td>
                                    <td><?php echo e($word->clue); ?></td>
                                    <?php if(session('role') != 'capacitante'): ?>
                                        <td>
                                            <div class="btn-group" role="group" aria-label="">
                                                <button type="button" class="btn btn-danger delete-word"
                                                    data-tr="<?php echo e($loop->iteration); ?>" data-title="<?php echo e($word->word); ?>"
                                                    data-word="<?php echo e($word->id); ?>"><i class="fa fa-trash"
                                                        aria-hidden="true"></i></button>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <h4 class="text-center my-4">No hay palabras registradas.</h4>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-12 <?php echo e(checkColGame(session('role'))); ?>">
                <?php if(session('role') != 'capacitante'): ?>
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-translucent-white">
                                <h2 class="font-weight-bold mt-3">Registrar Palabra</h2>
                            </div>
                            <div class="card-body">
                                <p class="card-text">Digita los datos para registrar una palabra</p>
                                <form action="<?php echo e(route('word.create')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="word" class="font-weight-bold">Palabra</label>
                                                <input type="text" name="word" id="word"
                                                    class="form-control <?php $__errorArgs = ['word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    placeholder="Palabra a registrar" aria-describedby="helpId">
                                                <?php $__errorArgs = ['word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small id="helpId"
                                                        class="bg-danger text-white font-weight-bold py-1"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="clue" class="font-weight-bold">Pista de palabra</label>
                                                <input type="text" name="clue" id="clue"
                                                    class="form-control <?php $__errorArgs = ['clue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    placeholder="Pista de la palabra a registrar" aria-describedby="helpId">
                                                <?php $__errorArgs = ['clue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small id="helpId"
                                                        class="bg-danger text-white font-weight-bold py-1"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="game" value="<?php echo e($juego->id); ?>">
                                    <div class="form-group float-right">
                                        <button type="submit" class="btn btn-outline-primary">Registrar</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-12 <?php echo e(checkColGame(session('role'))); ?>">
                <div class="card">
                    <div class="card-header bg-translucent-white">
                        <h2 class="font-weight-bold mt-3">Perfil Juego</h2>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Para actualizar la información del juego, digita sus datos.</p>
                        <form action="<?php echo e(route('game.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="game" value="<?php echo e($juego->id); ?>">
                            <div class="form-group">
                                <label for="title" class="font-weight-bold">Titulo del juego</label>
                                <input type="text" name="title" id="title"
                                    class="form-control text-capitalize <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e($juego->title); ?>" aria-describedby="helpId" <?php echo e(checkInput(session('role'))); ?>>
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId"
                                        class="bg-danger text-white font-weight-bold py-1 px-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php if(session('role') != 'capacitante'): ?>
                                <div class="form-group float-right">
                                    <button type="submit" class="btn btn-outline-primary">Actualizar</button>
                                </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('.delete-word').on('click', function() {
        var word = $(this).attr('data-title');
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡La palabra " + word.toUpperCase() + " Será eliminada!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '¡Si, eliminalo!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                var word = $(this).attr('data-word');
                axios.post("<?php echo e(route('word.delete')); ?>", {
                    _method: 'delete',
                    word: word,
                }).then(res => {
                    // console.log(res.data);
                    var titulo = (res.data.alert == 'success') ? '¡Eliminado!' : '¡Error';
                    Swal.fire(
                        titulo,
                        res.data.message,
                        res.data.alert
                    )

                });
                var fila = $(this).attr('data-tr');
                $("#fila" + fila).remove();
            }
        })
    });

</script>
<?php if(session()->has('create_complete')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '¡Éxito!',
            text: "<?php echo e(session('create_complete')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('create_failed')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "¡Error!",
            text: "<?php echo e(session('create_failed')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('update_complete')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '¡Éxito!',
            text: "<?php echo e(session('update_complete')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('update_failed')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "¡Error!",
            text: "<?php echo e(session('update_failed')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.argon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/auth/profiles/juego.blade.php ENDPATH**/ ?>