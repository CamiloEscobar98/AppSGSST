
<?php $__env->startSection('title', 'Perfil-Juego'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid mb-4">
        
        <div class="row">
            <div class="col-md-4">
                <div class="row">
                    <div class="col-12 mt-4">
                        <div class="card">
                            <div class="card-header bg-sgsst2 py-4">
                                <h4 class="font-weight-bold my-0">Juego</h4>
                            </div>
                            <div class="card-body">
                                <p class="card-text">Para actualizar la información del juego, digita sus datos.</p>
                                <form action="<?php echo e(route('game.update')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <input type="hidden" name="game" value="<?php echo e($juego->id); ?>">
                                    <div class="form-group">
                                        <label for="title" class="font-weight-bold">Titulo del juego</label>
                                        <input type="text" name="title" id="title"
                                            class="form-control text-capitalize <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e($juego->title); ?>" aria-describedby="helpId">
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId"
                                                class="bg-danger text-white font-weight-bold py-1 px-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-block btn-login">Actualizar</button>
                                    </div>
                                </form>
                            </div>
                            <div class="card-footer bg-sgsst2 py-4"></div>
                        </div>
                    </div>
                    <div class="col-12 mt-4">
                        <div class="card">
                            <div class="card-header bg-sgsst2 py-4">
                                <h4 class="font-weight-bold my-0">Registrar Palabra</h4>
                            </div>
                            <div class="card-body">
                                <p class="card-text">Digita los datos para registrar una palabra</p>
                                <form action="<?php echo e(route('word.create')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="game" value="<?php echo e($juego->id); ?>">
                                    <div class="form-group">
                                        <label for="word" class="font-weight-bold">Palabra</label>
                                        <input type="text" name="word" id="word"
                                            class="form-control <?php $__errorArgs = ['word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Palabra a registrar" aria-describedby="helpId">
                                        <?php $__errorArgs = ['word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId"
                                                class="bg-danger text-white font-weight-bold py-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="clue" class="font-weight-bold">Pista de palabra</label>
                                        <input type="text" name="clue" id="clue"
                                            class="form-control <?php $__errorArgs = ['clue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Pista de la palabra a registrar" aria-describedby="helpId">
                                        <?php $__errorArgs = ['clue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId"
                                                class="bg-danger text-white font-weight-bold py-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-block btn-login">Registrar</button>
                                    </div>
                                </form>
                            </div>
                            <div class="card-footer bg-sgsst2 py-4"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8 mt-4">
                <div class="card">
                    <div class="card-header bg-sgsst2 py-4">
                        <h4 class="font-weight-bold my-0">Lista de palabras</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover text-center">
                                <thead class="bg-sgsst2">
                                    <tr>
                                        <th style="width: 5%">No.</th>
                                        <th class="w-50">Palabra</th>
                                        <th class="w-50">Pista</th>
                                        <th class="w-auto">...</th>
                                    </tr>
                                </thead>
                                <tbody class="text-capitalize">
                                    <?php $__empty_1 = true; $__currentLoopData = $words; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr id="fila<?php echo e($loop->iteration); ?>">
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($word->word); ?></td>
                                            <td><?php echo e($word->clue); ?></td>
                                            <td>
                                                <div class="btn-group" role="group" aria-label="">
                                                    <button type="button" class="btn btn-danger delete-word"
                                                        data-tr="<?php echo e($loop->iteration); ?>" data-title="<?php echo e($word->word); ?>"
                                                        data-word="<?php echo e($word->id); ?>"><i class="fa fa-trash"
                                                            aria-hidden="true"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <h4 class="text-center my-4">No hay palabras registradas.</h4>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                                <tfoot class="bg-sgsst2">
                                    <th>No.</th>
                                    <th>Palabra</th>
                                    <th>Pista</th>
                                    <th>...</th>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer  bg-sgsst2 py-4"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('.delete-word').on('click', function() {
        var word = $(this).attr('data-title');
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡La palabra " + word.toUpperCase() + " Será eliminada!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '¡Si, eliminalo!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                var word = $(this).attr('data-word');
                axios.post("<?php echo e(route('word.delete')); ?>", {
                    _method: 'delete',
                    word: word,
                }).then(res => {
                    // console.log(res.data);
                    var titulo = (res.data.alert == 'success') ? '¡Eliminado!' : '¡Error';
                    Swal.fire(
                        titulo,
                        res.data.message,
                        res.data.alert
                    )

                });
                var fila = $(this).attr('data-tr');
                $("#fila" + fila).remove();
            }
        })
    });

</script>
<?php if(session()->has('create_complete')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '¡Éxito!',
            text: "<?php echo e(session('create_complete')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('create_failed')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "¡Error!",
            text: "<?php echo e(session('create_failed')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('update_complete')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '¡Éxito!',
            text: "<?php echo e(session('update_complete')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('update_failed')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "¡Error!",
            text: "<?php echo e(session('update_failed')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/auth/profiles/juego.blade.php ENDPATH**/ ?>