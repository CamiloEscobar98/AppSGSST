<footer class="container-fluid bg-sgsst py-5 shadow-lg">
    <p class="my-0 text-center font-weight-bold">Copyright &copy; 2020 Universidad Simón Bolivar, todos los derechos
        reservados.</p>
</footer>
<?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/layouts/footer.blade.php ENDPATH**/ ?>