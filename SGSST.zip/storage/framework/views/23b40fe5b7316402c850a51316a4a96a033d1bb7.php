
<?php $__env->startSection('title', 'Todas las temáticas'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.argon_nav_user_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt-4 mb-4">
        <div class="my-4">
            <?php if(auth()
            ->user()
            ->completeTopics()): ?>
                <div class="mt-4">
                    <div class="alert alert-default" role="alert">
                        <strong>¡Increíble!</strong> Has terminado de realizar todas las temáticas de la inducción.
                    </div>
                    <?php if(!Auth()->user()->formato): ?>
                        <a href="<?php echo e(route('user.formato')); ?>" class="btn btn-outline-success">Realizar Formato de
                            Inducción</a>
                    <?php else: ?>
                        
                        <a href="<?php echo e(route('user.downloadformato', Auth()->user()->formato)); ?>"
                            class="btn btn-outline-default">Descargar Formato</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <h2 class="font-weight-bold">Todas las temáticas</h2>
        <hr>
        <div class="row justify-content-start">
            <?php $__empty_1 = true; $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-12 col-md-4 mt-2 mb-4">
                    <div class="card h-100 rounded">
                        <div class="card-header bg-default"></div>
                        <div class="card-body">
                            <h4 class="card-title">
                                Estado
                            </h4>
                            <?php echo isCompleted($topic); ?>

                            <img src="<?php echo e(asset($topic->image->fullimage())); ?>"
                                class="img-fluid ${3|rounded-top,rounded-right,rounded-bottom,rounded-left,rounded-circle,|} mx-auto d-block"
                                alt="" width="100vh">
                            <h4 class="card-title font-weight-bold">Tema </h4>
                            <div class="card-text">
                                <p> <?php echo e($topic->title); ?></p>
                            </div>
                            <div class="card-title">
                                Descripción
                            </div>
                            <p class="card-text"><?php echo e($topic->info); ?></p>

                        </div>
                        <div class="card-footer bg-transparent">
                            <div class="btn-group float-right" role="group" aria-label="">

                                <?php if(!Auth()
                ->user()
                ->hasTopic($topic->title)): ?>
                                    <button type="button" class="btn btn-outline-success btn-inscribir"
                                        data-topic="<?php echo e($topic->title); ?>">Iniciar</button>
                                <?php else: ?>
                                    <?php if($topic->game): ?>
                                        <a href="<?php echo e(route('topic.show', $topic)); ?>" class="btn btn-outline-primary"><i
                                                class="fa fa-eye mr-2" aria-hidden="true"></i>Visualizar</a>
                                    <?php else: ?>
                                        <div class="alert alert-danger" role="alert">
                                            <strong>No disponible</strong>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>


                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>
        </div>
        <?php echo e($topics->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('.btn-inscribir').on('click', function() {
        var topic = $(this).attr('data-topic');
        axios.post("<?php echo e(route('user.addtopic')); ?>", {
            topic: topic,
            user: "<?php echo e(Auth()->user()->id); ?>"
        }).then(res => {
            // console.log(res.data);
            Swal.fire({
                title: res.data.title,
                text: res.data.message,
                icon: res.data.alert
            });
            setTimeout(() => {
                location.reload(true)
            }, 2000);

        }).catch(res => {
            // console.log(res);
            Swal.fire({
                title: res.data.title,
                text: 'Error, no se ha inscrito correctamente a la temática.',
                icon: 'error'
            });
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.argon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/auth/lists/tematicas.blade.php ENDPATH**/ ?>