
<?php $__env->startSection('title', 'Temática'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 mt-4">
                <div class="row">
                    <div class="col-12">
                        <div class="card shadow">
                            <div class="card-header bg-sgsst2 pt">
                                <h4 class="my-0 font-weight-bold">Temática</h4>
                            </div>
                            <div class="card-body">
                                <p class="card-title font-weight-bold">Capacitador</p>
                                <p class="card-text"><?php echo e($tema->user->fullname()); ?></p>
                                <p class="card-text">Actualizar la información de la temática.</p>
                                <img src="<?php echo e(asset($tema->image->fullimage())); ?>"
                                    class="img-fluid ${3|rounded-top,rounded-right,rounded-bottom,rounded-left,rounded-circle,|} mx-auto d-block"
                                    alt="" width="200vh">
                                <form action="<?php echo e(route('topic.update')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <input type="hidden" name="topic" value="<?php echo e($tema->id); ?>">
                                    <div class="form-group">
                                        <label for="title" class="font-weight-bold">Título:</label>
                                        <input type="text" name="title" id="title" value="<?php echo e($tema->title); ?>"
                                            class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder=""
                                            aria-describedby="helpId">
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId"
                                                class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="info" class="font-weight-bold">Descripción:</label>
                                        <textarea class="form-control <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="info"
                                            id="info" aria-describedby="helpId" rows="3"><?php echo e($tema->info); ?></textarea>
                                        <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId"
                                                class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-block btn-login">Actualizar</button>
                                    </div>
                                </form>
                            </div>
                            <div class="card-footer bg-sgsst2 py-4"></div>
                        </div>
                    </div>
                    <div class="col-12 mt-4 mb-4">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header bg-sgsst2 py-4">
                                        <h4 class="text-white font-weight-bold my-0">Cambiar Capacitador</h4>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?php echo e(route('topic.update-capacitante')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('patch'); ?>
                                            <input type="hidden" name="topic" value="<?php echo e($tema->id); ?>">
                                            <div class="form-group">
                                                <label for="capacitador" class="font-weight-bold">Capacitador:</label>
                                                <select class="form-control <?php $__errorArgs = ['capacitador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="capacitador" id="capacitador">
                                                    <option value="-1">Seleccione un capacitador</option>
                                                    <?php $__currentLoopData = $capacitadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capacitador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($capacitador->email == $tema->user->email): ?>
                                                            <option value="<?php echo e($capacitador->email); ?>" selected>
                                                                <?php echo e($capacitador->fullname()); ?>

                                                            </option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($capacitador->email); ?>">
                                                                <?php echo e($capacitador->fullname()); ?>

                                                            </option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['capacitador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small id="helpId" class="text-white bg-danger py-1"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-block btn-login">Actualizar</button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer bg-sgsst2 py-4"></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card shadow">
                                    <div class="card-header bg-sgsst2 py-4">
                                        <h4 class="text-white font-weight-bold my-0">Cambiar Foto</h4>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?php echo e(route('topic.update-photo')); ?>" method="POST" class="mt-4"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="topic" value="<?php echo e($tema->id); ?>">
                                            <?php echo method_field('patch'); ?>
                                            <div class="form-group">
                                                <div class="custom-file">
                                                    <input type="file"
                                                        class="custom-file-input <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="customFile" name="image">
                                                    <label class="custom-file-label" for="customFile">Seleccionar
                                                        foto</label>
                                                </div>
                                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small id="helpId"
                                                        class="form-text bg-danger font-weight-bold py-2 text-white px-2"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-login btn-block">Actualizar
                                                    foto</button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer bg-sgsst2 py-4"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8 mt-4">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-sgsst2 py-3">
                                <h4 class="font-weight-bold my-0">Cápsulas</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead class="thead-inverse">
                                            <tr class="bg-sgsst2 text-center">
                                                <th style="width: 5%">No.</th>
                                                <th>Título</th>
                                                <th>Link</th>
                                                <th>...</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-center">
                                            <?php $__empty_1 = true; $__currentLoopData = $capsules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capsula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr id="fila<?php echo e($loop->iteration); ?>">
                                                    <td><?php echo e($loop->iteration); ?>.</td>
                                                    <td><?php echo e($capsula->title); ?></td>
                                                    <td><a href="<?php echo e($capsula->video); ?>"><?php echo e($capsula->video); ?></a></td>
                                                    <td>
                                                        <div class="btn-group w-100">
                                                            <a href="<?php echo e(route('capsule.show', $capsula)); ?>" type="button"
                                                                class="btn btn-primary w-50"><i class="fa fa-eye"
                                                                    aria-hidden="true"></i></a>
                                                            <button type="button" class="btn btn-danger w-50 delete-capsule"
                                                                data-tr="<?php echo e($loop->iteration); ?>"
                                                                data-title="<?php echo e($capsula->title); ?>"
                                                                data-capsule="<?php echo e($capsula->id); ?>"><i class="fa fa-trash"
                                                                    aria-hidden="true"></i></button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <h4 class="mb-4">No hay cápsulas registradas.</h4>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                        <tfoot class="bg-sgsst2 text-center">
                                            <th>No.</th>
                                            <th>Título</th>
                                            <th>Link</th>
                                            <th>...</th>
                                        </tfoot>
                                    </table>
                                </div>
                                <?php echo e($capsules->links()); ?>

                            </div>
                            <div class="card-footer bg-sgsst2 py-4"></div>
                        </div>
                    </div>
                    <div class="col-12 mt-4 mb-4">
                        <div class="card">
                            <div class="card-header bg-sgsst2 py-4">
                                <h4 class="font-weight-bold my-0">Juego Interactivo</h4>
                            </div>
                            <div class="card-body row justify-content-center">
                                <?php if($tema->game == null): ?>
                                    <form action="<?php echo e(route('game.create')); ?>" method="post" class="col-md-8">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="topic" value="<?php echo e($tema->id); ?>">
                                        <div class="form-group">
                                            <label for="title_game" class="font-weight-bold">Titulo del Juego</label>
                                            <input type="text" name="title_game" id="title_game"
                                                value="<?php echo e(old('title_game')); ?>"
                                                class="form-control <?php $__errorArgs = ['title_game'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                placeholder="Titulo del juego" aria-describedby="helpId">
                                            <?php $__errorArgs = ['title_game'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="helpId"
                                                    class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label for="game_type" class="font-weight-bold">Tipo de juego</label>
                                            <select class="custom-select <?php $__errorArgs = ['game_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="game_type" id="game_type">
                                                <option value="-1" selected>Seleccione un tipo de juego</option>
                                                <option value="1">Ahorcado</option>
                                                <option value="2">Sopa de Letras</option>
                                            </select>
                                            <?php $__errorArgs = ['game_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small id="helpId"
                                                    class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-block btn-login">Registrar juego</button>
                                        </div>
                                    </form>
                                <?php else: ?>
                                    <?php if($tema->game->gameable->words()->count() != null): ?>
                                        <button class="btn btn-block btn-primary"
                                            onclick="mostrar_ocultar_juego('play_game')">Jugar</button>
                                        <a href="<?php echo e(route('game.show', $tema->game)); ?>" class="btn btn-block btn-login">Ver
                                            juego</a>
                                        <button type="button" class="btn btn-block btn-danger delete-game"
                                            data-game="<?php echo e($tema->game->id); ?>">Eliminar</button>

                                    <?php else: ?>
                                        <a href="<?php echo e(route('game.show', $tema->game)); ?>" class="btn btn-block btn-login">Ver
                                            juego</a>
                                        <button type="button" class="btn btn-block btn-danger delete-game"
                                            data-game="<?php echo e($tema->game->id); ?>">Eliminar</button>
                                    <?php endif; ?>
                                    <div id="play_game">
                                        <?php if($tema->game->type == 1): ?>
                                            <?php echo $__env->make('auth.games.hangman', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>
                                        <?php if($tema->game->type == 2): ?>
                                            <?php echo $__env->make('auth.games.wordfind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                            </div>
                            <div class="card-footer bg-sgsst2 py-4"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    mostrar_ocultar_juego('play_game')
    $('.delete-capsule').on('click', function() {
        var capsule = $(this).attr('data-title');
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡La cápsula " + capsule.toUpperCase() + " Será eliminado!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '¡Si, eliminalo!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                var capsule = $(this).attr('data-capsule');
                axios.post("<?php echo e(route('capsule.delete')); ?>", {
                    _method: 'delete',
                    capsule: capsule,
                }).then(res => {
                    var titulo = (res.data.alert == 'success') ? '¡Eliminado!' : '¡Error';
                    Swal.fire(
                        titulo,
                        res.data.message,
                        res.data.alert
                    )

                });
                var fila = $(this).attr('data-tr');
                $("#fila" + fila).remove();
            }
        })
    });

    function mostrar_ocultar_juego(id) {
        var play_game = document.getElementById(id);
        play_game.style.display = (play_game.style.display == 'none') ? 'block' : 'none';
    }

</script>
<?php if(session()->has('create_complete')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '¡Éxito!',
            text: "<?php echo e(session('create_complete')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('create_failed')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "¡Error!",
            text: "<?php echo e(session('create_failed')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('update_complete')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '¡Éxito!',
            text: "<?php echo e(session('update_complete')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('update_failed')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "¡Error!",
            text: "<?php echo e(session('update_failed')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<script>
    $('.delete-game').on('click', function() {
        Swal.fire({
            title: '¿Estás seguro?',
            text: "Se eliminará el juego..",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '¡Si, eliminalo!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                var game = $(this).attr('data-game');
                axios.post("<?php echo e(route('game.delete')); ?>", {
                    _method: 'delete',
                    game: game,
                }).then(res => {
                    var titulo = (res.data.alert == 'success') ? '¡Eliminado!' : '¡Error';
                    Swal.fire(
                        titulo,
                        res.data.message,
                        res.data.alert
                    )
                    setTimeout(() => {
                        location.reload(true)
                    }, 2000);

                });
            }
        })
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/auth/profiles/tema.blade.php ENDPATH**/ ?>