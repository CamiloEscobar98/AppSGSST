
<?php $__env->startSection('title', 'Temáticas'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid mb-4">
        <div class="row">
            <div class="col-md-4 mt-5">
                <div class="card shadow">
                    <div class="card-header bg-sgsst2 py-4">
                        <h4 class="font-weight-bold my-0">Registrar Temática</h4>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Por favor llena toda la información para registrar la temática.</p>
                        <form action="<?php echo e(route('topic.create')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="title" class="font-weight-bold">Título:</label>
                                <input type="text" name="title" id="title"
                                    class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder=""
                                    value="<?php echo e(old('title')); ?>" aria-describedby="helpId">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="info" class="font-weight-bold">Descripción:</label>
                                <textarea class="form-control <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="info" id="info"
                                    aria-describedby="helpId" rows="3"><?php echo e(old('info')); ?></textarea>
                                <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white font-weight-bold bg-danger py-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="capacitador" class="font-weight-bold">Capacitador:</label>
                                <select class="form-control <?php $__errorArgs = ['capacitador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="capacitador"
                                    id="capacitador">
                                    <option value="-1">Seleccione un capacitador</option>
                                    <?php $__currentLoopData = $capacitadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capacitador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($capacitador->email); ?>"><?php echo e($capacitador->fullname()); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['capacitador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white bg-danger py-1"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-block btn-login">Registrar</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer bg-sgsst2 py-4"></div>
                </div>
            </div>
            <div class="col-md-8 mt-5">
                <div class="card shadow">
                    <div class="card-header bg-sgsst2 py-4">
                        <h4 class="font-weight-bold text-white my-0">Lista de temáticas</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="bg-sgsst2 font-weight-bold text-center">
                                    <tr>
                                        <th>Foto</th>
                                        <th>Encargado</th>
                                        <th>Título</th>
                                        <th>...</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $tematicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr class="text-center" id="fila<?php echo e($loop->iteration); ?>">
                                            <td> <img src="<?php echo e(asset($tema->image->fullimage())); ?>"
                                                    class="img-fluid ${3|rounded-top,rounded-right,rounded-bottom,rounded-left,rounded-circle,|} mx-auto d-block"
                                                    alt="" width="50vh"></td>
                                            <td><a
                                                    href="<?php echo e(route('user.show', $tema->user)); ?>"><?php echo e($tema->user->fullname()); ?></a>
                                            </td>
                                            <td><?php echo e($tema->title); ?></td>
                                            <td>
                                                <div class="btn-group w-100">
                                                    <a href="<?php echo e(route('topic.show', $tema)); ?>" type="button"
                                                        class="btn btn-primary w-50"><i class="fa fa-eye"
                                                            aria-hidden="true"></i></a>
                                                    <button type="button" class="btn btn-danger w-50 delete-topic"
                                                        data-tr="<?php echo e($loop->iteration); ?>" data-title="<?php echo e($tema->title); ?>"
                                                        data-topic="<?php echo e($tema->id); ?>"><i class="fa fa-trash"
                                                            aria-hidden="true"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <?php endif; ?>
                                </tbody>
                                <tfoot class="bg-sgsst2 font-weight-bold text-center">
                                    <th>Foto</th>
                                    <th>Encargado</th>
                                    <th>Título</th>
                                    <th>...</th>
                                </tfoot>
                            </table>
                        </div>
                        <?php echo e($tematicas->links()); ?>

                    </div>
                    <div class="card-footer bg-sgsst2 py-4"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('.delete-topic').on('click', function() {
        var topic = $(this).attr('data-title');
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡La temática " + topic.toUpperCase() + " Será eliminado!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '¡Si, eliminalo!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                var topic = $(this).attr('data-topic');
                axios.post("<?php echo e(route('topic.delete')); ?>", {
                    _method: 'delete',
                    topic: topic,
                }).then(res => {
                    var titulo = (res.data.alert == 'success') ? '¡Eliminado!' : '¡Error';
                    Swal.fire(
                        titulo,
                        res.data.message,
                        res.data.alert
                    )

                });
                var fila = $(this).attr('data-tr');
                $("#fila" + fila).remove();
                setTimeout(() => {
                        location.reload(true)
                    }, 2000);
            }
        })
    });

</script>
<?php if(session()->has('create_complete')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '¡Éxito!',
            text: "<?php echo e(session('create_complete')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php if(session()->has('create_failed')): ?>
    <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "¡Error!",
            text: "<?php echo e(session('create_failed')); ?>",
            showConfirmButton: false,
            timer: 1500
        })

    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\SGSST\resources\views/auth/lists/lista-tematicas.blade.php ENDPATH**/ ?>